<template>
  <svg class="arrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 67.7 65.59" aria-labelledby="title" role="img">
    <title id="arrow">arrow</title>
    <path d="M71.41,63.31,55.23,73.74A2.82,2.82,0,1,1,52.17,69h0L63,62c-16.49-1.79-28.44-6.93-37-13.37A53.19,53.19,0,0,1,8,24.52a46.09,46.09,0,0,1-3-13A2.83,2.83,0,0,1,7.71,8.6a2.87,2.87,0,0,1,1.81.57,2.83,2.83,0,0,1,1.12,2.14h0v0a42,42,0,0,0,2.84,11.85,47.54,47.54,0,0,0,15.89,21C37.07,50,48,54.76,63.7,56.45L57,45.79a2.82,2.82,0,1,1,4.76-3L72.26,59.43A2.82,2.82,0,0,1,71.41,63.31Z" transform="translate(-5 -8.6)"/>
  </svg>
</template>

<script>
export default {}
</script>

<style scoped>
svg {
  position: absolute;
  width: 30px;
  top: 35px;
  left: 14px;
  fill: #42b983;
}

@media only screen and (max-width: 600px) {
  svg {
    width: 10px !important;
    top: 30px !important;
    left: 13px !important;
  }
}
</style>